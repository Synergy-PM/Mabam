
<?php $__env->startSection('title', 'Receivable Payments'); ?>
<?php $__env->startSection('header-title', 'Receivable Payments'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow-sm border-0">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Receivable Payments</h4>
            <a href="<?php echo e(route('receivable-payments.create')); ?>" class="btn btn-primary">
                <i class="mdi mdi-plus"></i> Add New
            </a>
        </div>

        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Dealer Name</th>
                            <th>Transaction Date</th>
                            <th>Amount Received</th>
                            <th>Payment Mode</th>
                            <th>Transaction type</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($payment->dealer->dealer_name ?? 'N/A'); ?></td>
                                <td><?php echo e($payment->transaction_date); ?></td>
                                <td><?php echo e(number_format($payment->amount_received, 2)); ?></td>
                                <td><?php echo e(ucfirst($payment->payment_mode)); ?></td>
                                <td><?php echo e(ucfirst($payment->transaction_type)); ?></td>
                                <td><?php echo e($payment->created_at->format('Y-m-d')); ?></td>
                                <td>
                                    <form action="<?php echo e(route('receivable-payments.delete', $payment->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger">
                                            <i class="mdi mdi-delete"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">No payments found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.shared', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\project\MK-Traders\resources\views/admin/receivable_payments/index.blade.php ENDPATH**/ ?>