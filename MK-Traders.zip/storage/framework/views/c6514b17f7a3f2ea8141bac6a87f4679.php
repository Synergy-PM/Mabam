<?php $__env->startSection('title', 'Payables'); ?>
<?php $__env->startSection('header-title', 'Payables'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="card shadow-sm border-0">
        <!-- Header -->
        <div class="card-header d-flex justify-content-between align-items-center bg-light">
          <h4 class="card-title mb-0">Payables</h4>
          <div class="d-flex gap-2">
            <a href="<?php echo e(route('payables.create')); ?>" class="btn btn-sm btn-primary">
              <i class="mdi mdi-plus"></i> Add
            </a>
            <a href="<?php echo e(route('payables.trash')); ?>" class="btn btn-sm btn-danger d-flex align-items-center gap-2">
              <i class="bi bi-trash-fill"></i> Trash
              <span class="badge bg-light text-dark ms-1"><?php echo e($trashCount ?? 0); ?></span>
            </a>
          </div>
        </div>

        <!-- Body -->
        <div class="card-body">
          <div class="table-responsive">
            <table id="payablesTable" class="table table-hover table-striped table-bordered align-middle">
              <thead class="table-light text-center">
                <tr>
                  <th>#</th>
                  <th>Supplier</th>
                  <th>Bags</th>
                  <th>Rate</th>
                  <th>Total</th>
                  <th>Bilti</th>
                  <th>Tons</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $payables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <!-- Proper numbering with pagination -->
                    <td class="text-center">
                      <?php echo e($loop->iteration + ($payables->currentPage()-1)*$payables->perPage()); ?>

                    </td>
                    <td><?php echo e($p->supplier->supplier_name ?? '-'); ?></td>
                    <td class="text-center"><?php echo e($p->no_of_bags); ?></td>
                    <td class="text-end"><?php echo e(number_format($p->amount_per_bag,2)); ?></td>
                    <td class="text-end"><?php echo e(number_format($p->total_amount,2)); ?></td>
                    <td><?php echo e($p->bilti_no ?? '-'); ?></td>
                    <td class="text-end"><?php echo e($p->tons); ?></td>
                    <td class="text-center"><?php echo e(\Carbon\Carbon::parse($p->transaction_date)->format('d-m-Y')); ?></td>
                    <td class="text-center">
                      <div class="d-flex justify-content-center gap-1">
                        <!-- Edit -->
                        <a href="<?php echo e(route('payables.edit', $p->id)); ?>"
                           class="btn btn-sm btn-soft-warning"
                           title="Edit">
                          <i class="mdi mdi-pencil"></i>
                        </a>
                        <!-- Delete -->
                        <form action="<?php echo e(route('payables.delete', $p->id)); ?>" method="POST"
                              onsubmit="return confirm('Move to trash?');">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button class="btn btn-sm btn-soft-danger" title="Delete">
                            <i class="mdi mdi-trash-can"></i>
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <!-- Pagination -->
          
        </div>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.shared', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\project\MK-Traders\resources\views/admin/Payable/index.blade.php ENDPATH**/ ?>