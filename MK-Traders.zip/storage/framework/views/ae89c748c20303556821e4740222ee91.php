
<?php $__env->startSection('title', 'Daily Transaction Report'); ?>
<?php $__env->startSection('header-title', 'Daily Transaction Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm rounded-3" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i> <?php echo e($error); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-12">
            <div class="card shadow border-0 rounded-4 overflow-hidden">
                <div class="card-header d-flex justify-content-between align-items-center bg-gradient bg-primary text-white p-3">
                    <div>
                        <h5 class="mb-0 text-white">
                            <i class="fas fa-calendar-day me-2"></i> Daily Transaction Report
                        </h5>
                        <div class="mt-2">
                            <?php if($selectedSupplier): ?>
                                <span class="badge bg-light text-dark me-1">Supplier: <?php echo e($selectedSupplier->name); ?></span>
                            <?php endif; ?>
                            <?php if($selectedDealer): ?>
                                <span class="badge bg-light text-dark me-1">Dealer: <?php echo e($selectedDealer->dealer_name); ?></span>
                            <?php endif; ?>
                            <?php if($startDate): ?>
                                <span class="badge bg-light text-dark">Date: <?php echo e(\Carbon\Carbon::parse($startDate)->format('d M, Y')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="d-flex align-items-center">
                        <button id="exportPDF" class="btn btn-light btn-sm shadow-sm me-2">
                            <i class="fas fa-file-pdf text-danger me-1"></i> Export PDF
                        </button>
                        <a href="<?php echo e(route('daily.report.filter')); ?>" class="btn btn-outline-light btn-sm">Back to Filter</a>
                    </div>
                </div>
                <div class="card-body bg-white">
                    <div class="border rounded-3 p-3 mb-4 bg-light shadow-sm">
                        <h6 class="fw-bold text-secondary mb-3">
                            <i class="fas fa-info-circle me-2"></i> Report Information
                        </h6>
                        <div class="row">
                            <div class="col-md-4">
                                <p class="mb-1"><strong>Generated On:</strong> <?php echo e(\Carbon\Carbon::now()->format('d M, Y')); ?></p>
                            </div>
                            <div class="col-md-4">
                                <p class="mb-1"><strong>Total Transactions:</strong> <?php echo e($reports->count()); ?></p>
                            </div>
                            <div class="col-md-4">
                                <p class="mb-1"><strong>Net Balance:</strong> <?php echo e(number_format($netBalance, 2)); ?> PKR</p>
                            </div>
                            <?php if($startDate): ?>
                                <div class="col-md-6 mt-2">
                                    <p class="mb-1"><strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($startDate)->format('d M, Y')); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="table-responsive shadow-sm rounded-3">
                        <table id="dailyReportTable" class="table table-bordered table-hover align-middle text-center mb-0">
                            <thead class="table-primary">
                                <tr>
                                    <th>S.No</th>
                                    <th>Type</th>
                                    <th>Name/Description</th>
                                    <th>Credit (PKR)</th>
                                    <th>Debit (PKR)</th>
                                    <th>Transaction Date</th>
                                    <th>Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $serial = 1;
                                    $runningBalance = 0;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($serial++); ?></td>
                                       <td><?php echo e($report['detected_type'] ?? 'N/A'); ?></td>
                                        <td><?php echo e($report['name']); ?></td>
                                        <td class="<?php echo e($report['amount'] > 100000 ? 'text-danger fw-bold' : ''); ?>">
                                            <?php echo e($report['is_credit'] ? number_format($report['amount'], 2) : '-'); ?>

                                        </td>
                                        <td class="<?php echo e($report['amount'] > 100000 ? 'text-danger fw-bold' : ''); ?>">
                                            <?php echo e(!$report['is_credit'] ? number_format($report['amount'], 2) : '-'); ?>

                                        </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($report['transaction_date'])->format('d M, Y')); ?></td>
                                        <td>
                                            <?php
                                                $runningBalance += $report['is_credit'] ? -$report['amount'] : $report['amount'];
                                            ?>
                                            <?php echo e(number_format($runningBalance, 2)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">
                                            <i class="fas fa-folder-open me-2"></i> No transactions found for the selected date. Try adjusting the filters.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <tr class="table-secondary fw-bold">
                                    <td colspan="3" class="text-end">Grand Total</td>
                                    <td><?php echo e(number_format($totalPayable + $totalReceivablePayment, 2)); ?></td>
                                    <td><?php echo e(number_format($totalReceivable, 2)); ?></td>
                                    <td></td>
                                    <td><?php echo e(number_format($runningBalance, 2)); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="row mt-4 g-3">
                        <div class="col-md-3">
                            <div class="card bg-success text-white">
                                <div class="card-body text-center">
                                    <h6 class="mb-0">Total Payable</h6>
                                    <h5 class="mt-1"><?php echo e(number_format($totalPayable, 2)); ?> PKR</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-info text-white">
                                <div class="card-body text-center">
                                    <h6 class="mb-0">Total Receivable</h6>
                                    <h5 class="mt-1"><?php echo e(number_format($totalReceivable, 2)); ?> PKR</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-warning text-dark">
                                <div class="card-body text-center">
                                    <h6 class="mb-0">Total Receivable Payment</h6>
                                    <h5 class="mt-1"><?php echo e(number_format($totalReceivablePayment, 2)); ?> PKR</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-secondary text-white">
                                <div class="card-body text-center">
                                    <h6 class="mb-0">Net Balance</h6>
                                    <h5 class="mt-1"><?php echo e(number_format($netBalance, 2)); ?> PKR</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .table-responsive {
            max-height: 65vh;
            overflow-y: auto;
        }
        @media (max-width: 767.98px) {
            .card .card-body h5 { font-size: 1rem; }
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.13/jspdf.plugin.autotable.min.js"></script>
    <script>
        document.getElementById('exportPDF').addEventListener('click', function () {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('p', 'pt', 'a4');
            const companyName = "HK Group of Companies";
            const title = "Daily Transaction Report";
            const today = "<?php echo e(\Carbon\Carbon::now()->format('d M, Y')); ?>";
            doc.setFontSize(12);
            doc.setFont('helvetica', 'bold');
            doc.text(companyName, 40, 40);
            doc.setFontSize(14);
            doc.text(title, 40, 60);
            doc.setFontSize(10);
            doc.setFont('helvetica', 'normal');
            let filterInfo = '';
            <?php if($selectedSupplier): ?>
                filterInfo += `Supplier: <?php echo e($selectedSupplier->name); ?> | `;
            <?php endif; ?>
            <?php if($selectedDealer): ?>
                filterInfo += `Dealer: <?php echo e($selectedDealer->dealer_name); ?> | `;
            <?php endif; ?>
            <?php if($startDate): ?>
                filterInfo += `Date: <?php echo e(\Carbon\Carbon::parse($startDate)->format('d M, Y')); ?>`;
            <?php endif; ?>
            doc.text(`Generated On: ${today}`, 40, 78);
            doc.text(filterInfo, 40, 90);
            doc.autoTable({
                html: '#dailyReportTable',
                startY: 100,
                theme: 'grid',
                headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold' },
                styles: { fontSize: 8, cellPadding: 4 },
                margin: { left: 40, right: 40 },
                columnStyles: {
                    0: { cellWidth: 30 }, // S.No
                    1: { cellWidth: 60 }, // Type
                    2: { cellWidth: 100 }, // Name/Description
                    3: { cellWidth: 60 }, // Credit
                    4: { cellWidth: 60 }, // Debit
                    5: { cellWidth: 60 }, // Transaction Date
                    6: { cellWidth: 60 }, // Balance
                },
                didDrawPage: function (data) {
                    const pageHeight = doc.internal.pageSize.getHeight();
                    doc.setFontSize(9);
                    const pageNumber = doc.internal.getCurrentPageInfo().pageNumber;
                    doc.text(`Generated on: ${today} | Page ${pageNumber}`, 40, pageHeight - 30);
                }
            });
            const finalY = doc.lastAutoTable ? doc.lastAutoTable.finalY + 20 : 120;
            doc.setFontSize(11);
            doc.setFont('helvetica', 'bold');
            doc.text("Grand Totals:", 40, finalY);
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(10);
            doc.text(`Payable: <?php echo e(number_format($totalPayable, 2)); ?> PKR`, 40, finalY + 14);
            doc.text(`Receivable: <?php echo e(number_format($totalReceivable, 2)); ?> PKR`, 40, finalY + 24);
            doc.text(`Receivable Payment: <?php echo e(number_format($totalReceivablePayment, 2)); ?> PKR`, 40, finalY + 34);
            const filename = `Daily_Transaction_Report_<?php echo e(\Carbon\Carbon::now()->format('d_M_Y')); ?>.pdf`;
            doc.save(filename);
        });
    </script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.shared', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\project\MK-Traders\resources\views/admin/reports/daily_report.blade.php ENDPATH**/ ?>