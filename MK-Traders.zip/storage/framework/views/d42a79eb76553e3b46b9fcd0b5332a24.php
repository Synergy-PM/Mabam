
<?php $__env->startSection('title', 'Expenses'); ?>
<?php $__env->startSection('header-title', 'Expenses'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow-sm border-0">
                <div class="card-header d-flex justify-content-between align-items-center bg-light">
                    <h4 class="card-title mb-0">Expenses List</h4>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-sm btn-primary">
                            <i class="mdi mdi-plus"></i> Add Expense
                        </a>
                        <a href="<?php echo e(route('expenses.trash')); ?>" class="btn btn-sm btn-danger d-flex align-items-center gap-2"
                            title="Deleted Expenses">
                            <i class="bi bi-trash-fill"></i>
                            <span>Trash</span>
                            <span class="badge bg-light text-dark"><?php echo e($trashExpenses ?? 0); ?></span>
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="expensesTable" class="table table-hover table-striped table-bordered align-middle text-center">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Description</th>
                                    <th>Amount</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($expense->expense_date)->format('d M Y')); ?></td>
                                        <td><?php echo e($expense->expense_description); ?></td>
                                        <td><?php echo e(number_format($expense->amount, 2)); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('expenses.edit', $expense->id)); ?>"
                                                class="btn btn-sm btn-soft-warning"><i class="mdi mdi-pencil"></i></a>
                                            <form action="<?php echo e(route('expenses.delete', $expense->id)); ?>" method="POST" style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-soft-danger">
                                                    <i class="mdi mdi-trash-can"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('#expensesTable').DataTable({
        pageLength: 10,
        responsive: true,
        autoWidth: false,
        order: [[1, 'desc']], // Sort by Date
        columnDefs: [
            { orderable: false, targets: [0, 4] } // # and Actions
        ]
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.shared', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\project\MK-Traders\resources\views/admin/expenses/index.blade.php ENDPATH**/ ?>