
<?php $__env->startSection('title', 'Add Expense'); ?>
<?php $__env->startSection('header-title', 'Add Expense'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <form action="<?php echo e(route('expenses.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label><b>Expense Date</b><span class="text-danger">*</span></label>
                            <input type="date" name="expense_date" class="form-control" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label><b>Expense Description</b><span class="text-danger">*</span></label>
                            <input type="text" name="expense_description" class="form-control" placeholder="Enter expense details" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label><b>Amount</b><span class="text-danger">*</span></label>
                            <input type="number" name="amount" step="0.01" class="form-control" placeholder="Enter amount" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><b>Save Expense</b></button>
                    <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-secondary">Cancel</a>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.shared', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\project\MK-Traders\resources\views/admin/expenses/create.blade.php ENDPATH**/ ?>