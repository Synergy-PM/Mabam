<!-- Updated admin/reports/daily-report-filter.blade.php -->

<?php $__env->startSection('title', 'Daily Report Filter'); ?>
<?php $__env->startSection('header-title', 'Daily Report Filter'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h4 class="mb-4 fw-semibold">Daily Expense Report Filter</h4>
                
                <form method="GET" action="<?php echo e(route('daily.report')); ?>">
                    <div class="row">
                        
                        <div class="col-md-2 mb-3">
                            <label class="form-label">From Date</label>
                            <input type="date" name="start_date" value="<?php echo e(request('start_date')); ?>" class="form-control">
                        </div>
                        
                        <div class="col-md-2 mb-3">
                            <label class="form-label">To Date</label>
                            <input type="date" name="end_date" value="<?php echo e(request('end_date')); ?>" class="form-control">
                        </div>
                        
                        <div class="col-md-4 mb-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-2"></i>View Report
                            </button>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-4">
                            <a href="<?php echo e(route('daily.report')); ?>" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-refresh me-2"></i>Reset to Today
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.shared', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\project\MK-Traders\resources\views/admin/reports/daily-report-filter.blade.php ENDPATH**/ ?>