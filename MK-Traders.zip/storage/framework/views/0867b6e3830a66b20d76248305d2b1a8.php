<?php $__env->startSection('title', 'Payable Payments'); ?>
<?php $__env->startSection('header-title', 'Payable Payments'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="card shadow-sm border-0">
        <!-- Header -->
        <div class="card-header d-flex justify-content-between align-items-center bg-light">
          <h4 class="card-title mb-0">Payable Payments</h4>
          <div class="d-flex gap-2">
            <a href="<?php echo e(route('payable-payments.create')); ?>" class="btn btn-sm btn-primary">
              <i class="mdi mdi-plus"></i> Add
            </a>
            <a href="<?php echo e(route('payable-payments.trash')); ?>" class="btn btn-sm btn-danger d-flex align-items-center gap-2">
              <i class="bi bi-trash-fill"></i> Trash
              <span class="badge bg-light text-dark ms-1"><?php echo e($trashCount ?? 0); ?></span>
            </a>
          </div>
        </div>

        <!-- Body -->
        <div class="card-body">
          <div class="table-responsive">
            <table id="payablePaymentsTable" class="table table-hover table-striped table-bordered align-middle">
              <thead class="table-light text-center">
                <tr>
                  <th>#</th>
                  <th>Supplier</th>
                  <th>Transaction Date</th>
                  <th>Amount</th>
                  
                  <th>Proof</th>
                  
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <!-- Pagination-wise numbering -->
                    <td class="text-center">
                      <?php echo e($loop->iteration + ($payments->currentPage() - 1) * $payments->perPage()); ?>

                    </td>
                    <td><?php echo e($payment->supplier->supplier_name ?? '-'); ?></td>
                    <td class="text-center"><?php echo e(\Carbon\Carbon::parse($payment->transaction_date)->format('d M, Y')); ?></td>
                    <td class="text-end"><?php echo e(number_format($payment->amount, 2)); ?></td>
                    <td class="text-center"><?php echo e(ucfirst($payment->payment_mode) ?? '-'); ?></td>
                    
                    
                    <td class="text-center">
                      <div class="d-flex justify-content-center gap-1">
                        <!-- Edit -->
                        <a href="<?php echo e(route('payable-payments.edit', $payment->id)); ?>" 
                           class="btn btn-sm btn-soft-warning" 
                           title="Edit">
                          <i class="mdi mdi-pencil"></i>
                        </a>
                        <!-- Delete -->
                        <form action="<?php echo e(route('payable-payments.delete', $payment->id)); ?>" method="POST" 
                              onsubmit="return confirm('Move to trash?');">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button class="btn btn-sm btn-soft-danger" title="Delete">
                            <i class="mdi mdi-trash-can"></i>
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <!-- Pagination -->
          <div class="mt-3">
            <?php echo e($payments->links()); ?>

          </div>
        </div>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.shared', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\project\MK-Traders\resources\views/admin/payable_payments/index.blade.php ENDPATH**/ ?>