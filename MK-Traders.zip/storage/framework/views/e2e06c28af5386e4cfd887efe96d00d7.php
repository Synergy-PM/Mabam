<?php $__env->startSection('title', 'Cities'); ?>
<?php $__env->startSection('header-title', 'Cities'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow-sm border-0">
                <div class="card-header d-flex justify-content-between align-items-center bg-light">
                    <h4 class="card-title mb-0">Cities List</h4>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('cities.create')); ?>" class="btn btn-sm btn-primary">
                            <i class="mdi mdi-plus"></i> Add City
                        </a>
                        <a href="<?php echo e(route('cities.trash')); ?>" class="btn btn-sm btn-danger d-flex align-items-center gap-2"
                            title="Deleted Cities">
                            <i class="bi bi-trash-fill"></i>
                            <span>Trash</span>
                            <span class="badge bg-light text-dark"><?php echo e($trashCities ?? 0); ?></span>
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="citiesTable"
                            class="table table-hover table-striped table-bordered align-middle text-center">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($city->name); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('cities.edit', $city->id)); ?>"
                                                class="btn btn-sm btn-soft-warning"><i class="mdi mdi-pencil"></i></a>
                                            <form action="<?php echo e(route('cities.delete', $city->id)); ?>" method="POST"
                                                style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-soft-danger"><i
                                                        class="mdi mdi-trash-can"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('#citiesTable').DataTable({
        pageLength: 10,
        responsive: true,
        autoWidth: false,
        order: [[1, 'asc']], // Name column
        columnDefs: [
            { orderable: false, targets: [0, 2] } // # and Actions
        ]
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.shared', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\project\MK-Traders\resources\views/admin/cities/index.blade.php ENDPATH**/ ?>