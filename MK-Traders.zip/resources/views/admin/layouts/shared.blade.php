@include('admin.layouts.header')
@yield('content')
@include('admin.layouts.footer')    